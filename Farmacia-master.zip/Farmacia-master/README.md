# Farmacia
Pre requisitos para windows 7:

Sql Server 2014
Link
ExpressAndTools 64BIT\SQLEXPRWT_x64_ESN.exe

- SQLManagementStudio
- SQLSERVEReXPRESS

VISUAL STUDIO 2022

Tomamos desde 
https://www.youtube.com/watch?v=5x79o72E0pw&t=35s&ab_channel=JEVSOFT

Patron de diseño MVC
https://developer.mozilla.org/es/docs/Glossary/MVC


Campos

